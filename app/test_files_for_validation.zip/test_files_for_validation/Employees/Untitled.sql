USE northwind;
SHOW COLUMNS FROM Categories;

-- Show records of tables
select * from northwind.Categories;
select * from northwind.Customers;
select * from northwind.Employees;
select * from northwind.OrderDetails limit 100;
select * from northwind.Orders limit 10;
select * from northwind.Products;
select * from northwind.Shippers;
select * from northwind.Suppliers;

select distinct(Country) from northwind.Customers;

SELECT UnitPrice FROM northwind.Products WHERE ProductID = 1;

SELECT MAX(OrderID) as nextid FROM northwind.OrderDetails;

select * from `sales by category`;